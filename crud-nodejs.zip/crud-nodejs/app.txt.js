
const express = require('express');
const mongoose = require('mongoose');
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');
const morgan = require('morgan');

const app = express();
const port = process.env.PORT || 3000;


app.use(express.json());
app.use(morgan('combined'));

const authRoutes = require('./routes/auth');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));


const dogRoutes = require('./routes/dogs');
app.use('/dogs', dogRoutes);
app.use('/auth', authRoutes);

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Internal Server Error' });
});


const dbUrl = process.env.MONGO_URI || 'mongodb://mongo:27017/dogsdb';
mongoose
    .connect(dbUrl,{ useNewUrlParser: true, useUnifiedTopology: true } )
    .then(() => {
        console.log('MongoDB connected');
        app.listen(port, () => console.log(`Server running on port ${port}`));
    })
    .catch((err) => {
        console.error('MongoDB connection error:', err);
    });

module.exports = app;
