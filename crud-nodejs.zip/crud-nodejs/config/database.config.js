

module.exports = {

  url: process.env.MONGO_URI || 'mongodb://mongodb:27017/dogsdb',


  options: {
    useNewUrlParser: true,
    useUnifiedTopology: true,


  },
};
