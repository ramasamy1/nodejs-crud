
const mongoose = require('mongoose');

const dogSchema = new mongoose.Schema({
    breed: { type: String, required: true },
    description: { type: String },
    pictureUrl: { type: String },
    height: { type: Number },
    weight: { type: Number },
    lifeSpan: { type: String },

    breedCharacteristics: { type: [String], default: [] },
}, { timestamps: true });

module.exports = mongoose.model('Dog', dogSchema);
