
const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();


const users = [
    {
        id: 1,
        username: 'admin',
        password: 'password',
        role: 'admin',
    },
];

router.post('/login', (req, res) => {
    const { username, password } = req.body;


    const user = users.find(
        (u) => u.username === username && u.password === password
    );

    if (!user) {
        return res.status(401).json({ message: 'Invalid credentials' });
    }


    const payload = {
        id: user.id,
        username: user.username,
        role: user.role,
    };


    const token = jwt.sign(payload, process.env.JWT_SECRET || 'default_jwt_secret', {
        expiresIn: '1h',
    });

    return res.json({ token });
});

module.exports = router;
