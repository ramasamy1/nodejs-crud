
const express = require('express');
const { body, query, validationResult } = require('express-validator');
const Dog = require('../models/Dog');
const redis = require('redis');
const router = express.Router();
const verifyToken = require('../middleware/verifyToken');

const redisClient = redis.createClient({
  host: process.env.REDIS_HOST || 'localhost', // 'redis' when inside Docker
  port: process.env.REDIS_PORT || 6379,
});


redisClient.on('error', (err) => {
  console.error('Redis error:', err);
});

const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};


router.post(
    '/',
    verifyToken,
    [
      body('breed').notEmpty().withMessage('Breed is required'),
      body('pictureUrl').optional().isURL().withMessage('Picture URL must be valid'),

    ],
    validateRequest,
    async (req, res) => {
      try {
        const dog = new Dog(req.body);
        await dog.save();
        res.status(201).json(dog);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    }
);


router.get(
    '/',
    [
      query('page').optional().isInt({ gt: 0 }).withMessage('Page must be a positive integer'),
      query('limit').optional().isInt({ gt: 0 }).withMessage('Limit must be a positive integer'),
    ],
    validateRequest,
    async (req, res) => {
      try {

        const page = Number(req.query.page) || 1;
        const limit = Number(req.query.limit) || 10;
        const { breed } = req.query;

        const cacheKey = `dogs:${page}:${limit}:${breed || 'all'}`;

        // Attempt to get cached data
        redisClient.get(cacheKey, async (err, cachedData) => {
          if (err) {
            console.error('Error fetching from Redis:', err);
            // Optionally handle cache failure and continue with a DB lookup.
          }

          if (cachedData !== null) {
            console.log('Serving from cache');
            return res.json(JSON.parse(cachedData));
          } else {
            // Build MongoDB filter
            const filter = {};
            if (breed) {
              filter.breed = new RegExp(breed, 'i');
            }

            const dogs = await Dog.find(filter)
                .skip((page - 1) * limit)
                .limit(limit);

            // Cache the result in Redis for 60 seconds
            redisClient.setex(cacheKey, 60, JSON.stringify(dogs));

            console.log('Serving from MongoDB');
            return res.json(dogs);
          }
        });
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    }
);


router.get('/:id', async (req, res) => {
  try {
    const dog = await Dog.findById(req.params.id);
    if (!dog) {
      return res.status(404).json({ error: 'Dog not found' });
    }
    res.json(dog);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


router.put(
    '/:id',
    verifyToken,
    [
      body('breed').optional().notEmpty().withMessage('Breed cannot be empty'),
      body('pictureUrl').optional().isURL().withMessage('Picture URL must be valid'),
    ],
    validateRequest,
    async (req, res) => {
      try {
        const updatedDog = await Dog.findByIdAndUpdate(req.params.id, req.body, {
          new: true,
          runValidators: true,
        });
        if (!updatedDog) {
          return res.status(404).json({ error: 'Dog not found' });
        }
        res.json(updatedDog);
      } catch (err) {
        res.status(500).json({ error: err.message });
      }
    }
);


router.delete('/:id', verifyToken,async (req, res) => {
  try {
    const dog = await Dog.findByIdAndDelete(req.params.id);
    if (!dog) {
      return res.status(404).json({ error: 'Dog not found' });
    }
    res.json({ message: 'Dog deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
