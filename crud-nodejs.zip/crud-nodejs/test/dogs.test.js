
const request = require('supertest');
const mongoose = require('mongoose');
const app = require('../app');
const Dog = require('../models/Dog');

beforeAll(async () => {
    const dbUrl = process.env.MONGO_URL || 'mongodb://localhost:27017/dogsdb_test';
    await mongoose.connect(dbUrl, { useNewUrlParser: true, useUnifiedTopology: true });
});

afterAll(async () => {
    await mongoose.connection.db.dropDatabase();
    await mongoose.disconnect();
});

describe('Dog API', () => {
    let dogId;

    test('should create a new dog', async () => {
        const response = await request(app).post('/dogs').send({
            breed: 'Beagle',
            description: 'Friendly and curious',
            pictureUrl: 'http://example.com/beagle.jpg',
            height: 33,
            weight: 10,
            lifeSpan: '12-15 years',
            breedCharacteristics: ['Adaptable', 'Kid-Friendly']
        });
        expect(response.statusCode).toBe(201);
        expect(response.body).toHaveProperty('_id');
        dogId = response.body._id;
    });

    test('should retrieve the created dog', async () => {
        const response = await request(app).get(`/dogs/${dogId}`);
        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('breed', 'Beagle');
    });

    test('should update the dog', async () => {
        const response = await request(app).put(`/dogs/${dogId}`).send({ description: 'Very friendly' });
        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('description', 'Very friendly');
    });

    test('should delete the dog', async () => {
        const response = await request(app).delete(`/dogs/${dogId}`);
        expect(response.statusCode).toBe(200);
        expect(response.body).toHaveProperty('message', 'Dog deleted successfully');
    });
});
